# Conclusão

Se você chegou até aqui no livro meus parabéns e obrigado por fazer parte desse material, seja lendo, adquirindo o livro ou até mesmo assistindo os vídeos do canal no youtube.

Para os que desejam ir em busca da certificação Docker DCA, minha sugestão é simples: Leiam e reproduzam todo o conteúdo no mínimo três vezes. Sendo a primeira vez acompanhando o material na íntegra linha por linha, a segunda vez acompanhando e recordando, e a terceira vez reproduzindo porém olhando poucas vezes o material. 

Caso esteja inseguro ou queira experimentar novos laboratórios, sinta-se livre para modificar alguns parâmetros e experimentar, porém minha dica é que só faça isso após entender todo o básico, pois você pode encontrar um problema não documentado e ocorrer alguma frustração. Mas se você é daqueles que, como eu, gosta quando um problema aparece e pesquisa até achar a solução, vá em frente! 

Desejo a você uma boa sorte na prova e espero que esse material seja útil para você em sua jornada pelo mundo de Containers.

